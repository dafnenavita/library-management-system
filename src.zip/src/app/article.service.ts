import { Injectable } from '@angular/core';
import { Http, Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import 'rxjs/add/operator/map';

import { Article, SearchResult, SearchResultCheckIn, Borrower, FineDetails, FineDisplay } from './article';

@Injectable()
export class ArticleService {
// URLs for CRUD operations
allArticlesUrl = 'http://localhost:8080/user/all-articles';
articleUrl = 'http://localhost:8080/user/article';
getBooksBySearchParamUrl = 'http://localhost:8080/user/book/?searchParam=';
checkOutBookUrl = 'http://localhost:8080/user/checkOutBook?';
checkInUrl = 'http://localhost:8080/user/checkIn?searchParam=';
addBorrowerUrl = 'http://localhost:8080/user/addBorrower';
retrieveAndUpdateFinesUrl = 'http://localhost:8080/user/retrieveAndUpdateFines';
// Create constructor to get Http instance
constructor(private http: Http) {
}
// Fetch all articles
getAllArticles(): Observable<Article[]> {
return this.http.get(this.allArticlesUrl)
.map(this.extractData)
.catch(this.handleError);

}

// Fetch all books
getBooksBySearchParam(title: string): Observable<SearchResult[]> {
const url = this.getBooksBySearchParamUrl + title;
return this.http.get(url).map(this.extractData)
;

}

// Fetch all books
getCheckedInBooks(title: string): Observable<SearchResultCheckIn[]> {
const url = this.checkInUrl + title;
return this.http.get(url).map(this.extractData);

}

// get fines
getFines(): Observable<FineDisplay[]> {
const cpHeaders = new Headers({ 'Content-Type': 'application/json' });
const options = new RequestOptions({ headers: cpHeaders });
const finesurl = this.retrieveAndUpdateFinesUrl;
return this.http.post(finesurl, options).map(this.extractData)
;
   }
// Create article
createArticle(article: Article): Observable<number> {
const cpHeaders = new Headers({ 'Content-Type': 'application/json' });
const options = new RequestOptions({ headers: cpHeaders });
return this.http.post(this.articleUrl, article, options)
   .map(success => success.status)
   .catch(this.handleError);
}
// Fetch article by id
getArticleById(articleId: string): Observable<Article> {
const cpHeaders = new Headers({ 'Content-Type': 'application/json' });
const cpParams = new URLSearchParams();
cpParams.set('id', articleId);
const options = new RequestOptions({ headers: cpHeaders, params: cpParams });
return this.http.get(this.articleUrl, options)
   .map(this.extractData)
   .catch(this.handleError);
}
// Update article
updateArticle(article: Article): Observable<number> {
const cpHeaders = new Headers({ 'Content-Type': 'application/json' });
const options = new RequestOptions({ headers: cpHeaders });
return this.http.put(this.articleUrl, article, options)
   .map(success => success.status)
   .catch(this.handleError);
}
// Deconste article
deconsteArticleById(articleId: string): Observable<number> {
const cpHeaders = new Headers({ 'Content-Type': 'application/json' });
const cpParams = new URLSearchParams();
cpParams.set('id', articleId);
const options = new RequestOptions({ headers: cpHeaders, params: cpParams });
return this.http.delete(this.articleUrl, options)
   .map(success => success.status)
   .catch(this.handleError);
}
private extractData(res: Response) {
const body = res.json();
return body;
}
private handleError (error: Response | any) {
console.error(error.message || error);
return Observable.throw(error.status);
}

// checkout book
checkOutBook(cardId: string, isbn: string): Observable<number> {
const cpHeaders = new Headers({ 'Content-Type': 'application/json' });
const options = new RequestOptions({ headers: cpHeaders });
const url = this.checkOutBookUrl + 'cardId=' + cardId + '&isbn=' + isbn ;
return this.http.post(url, options)
   .map(this.extractData);
}


// add borrower
addBorrower(borrower: Borrower): Observable<number> {
const cpHeaders = new Headers({ 'Content-Type': 'application/json' });
const options = new RequestOptions({ headers: cpHeaders });
return this.http.post(this.addBorrowerUrl, borrower, options)
   .map(this.extractData);

}}
