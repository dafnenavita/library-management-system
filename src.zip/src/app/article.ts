export class Article {
    constructor(public articleId: string, public title: string, public category: string) {
    }
}

export class SearchResult {
    constructor(public isbn: string, public title: string, public authorName: string, public availability: string) {
    }
}

export class SearchResultCheckIn {
    constructor(public Loan_id: string, public card_no: string, public bFirstname: string, public bLastname: string, public Isbn: string, public Date_out: string, public Due_date: string, public Date_in: string, public checked: string) {
    }
}

export class Borrower {
    constructor(public card_Id: string, public ssn: string, public bFirstname: string, public bLastname: string, public bEmail: string, public address: string, public city: string, public state: string, public phone: string) {
    }
}

export class FineDetails {
    constructor(public loan_id: string, public fine_amt: string, public paid: string, public bookName: string, public cardId: string, public borrowerName: string, public dateIn: string, public dateOut: string, public dueDate: string) {
    }
}

export class FineDisplay {
    constructor(public cardId: string, public name: string, public fine1: string, public fine2: string, public fine3: string, public borrowerName: string, public paid: string) {
    }
}
