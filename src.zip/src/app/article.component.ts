import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { ArticleService } from './article.service';
import { Article, FineDisplay, SearchResult, SearchResultCheckIn, Borrower, FineDetails } from './article';

@Component({
    selector: 'app-article',
    templateUrl: './article.component.html',
    styleUrls: ['./article.component.css']
})
export class ArticleComponent implements OnInit {
    // Component properties
    allArticles: Article[];
    allSearchResultCheckIns: SearchResultCheckIn[];
    statusCode: number;
    mode: number;
    renderSearchTable = false;
    requestProcessing = false;
    articleIdToUpdate = null;
    processValidation = false;
    checkOutCode: number;
    borrower: Borrower;
    borrowerCode: number;
    allFines: FineDisplay[];
    errorMessage: string;
    allSearchResults: SearchResult[];
    articleForm = new FormGroup({
        title: new FormControl('', Validators.required),
        category: new FormControl('', Validators.required)
    });

    checkOutForm = new FormGroup({
        isbn: new FormControl('', Validators.required),
        cardID: new FormControl('', Validators.required)
    });
    checkInForm = new FormGroup({
        title: new FormControl('', Validators.required)
    });
    mode1 = new FormGroup({
    });
    mode2 = new FormGroup({
    });
    mode3 = new FormGroup({
    });
    mode4 = new FormGroup({
    });
    mode5 = new FormGroup({
    });

    addBorrowerForm = new FormGroup({
        cardID: new FormControl('', Validators.required),
        SSN: new FormControl('', Validators.required),
        FirstName: new FormControl('', Validators.required),
        LastName: new FormControl('', Validators.required),
        Email: new FormControl('', Validators.required),
        Address: new FormControl('', Validators.required),
        City: new FormControl('', Validators.required),
        State: new FormControl('', Validators.required),
        Phone: new FormControl('', Validators.required)
    });

    // Create constructor to get service instance
    constructor(private articleService: ArticleService) {
    }
    // Create ngOnInit() and and load articles
    ngOnInit(): void {
        this.mode = 1;
    }
    // Fetch all articles
    getAllArticles() {
        this.articleService.getAllArticles()
            .subscribe(
            data => this.allArticles = data,
            errorCode => this.statusCode = errorCode);
    }

    // Handle create and update article
    onArticleFormSubmit() {
        this.renderSearchTable = false;
        this.errorMessage = null;
        const title = this.articleForm.get('title').value.trim();
        if (title == null || title === '') {
            this.errorMessage = 'Please enter a valid Search Keyword';
            return;
        }

        this.articleService.getBooksBySearchParam(title)
        .subscribe(
        data => this.allSearchResults = data,
        errorCode => this.statusCode = errorCode);
        // console.log(this.allSearchResults);

        this.renderSearchTable = true;
        return;
    }

    // checkout
    onCheckOutSubmit() {
        const isbn = this.checkOutForm.get('isbn').value.trim();
        const cardID = this.checkOutForm.get('cardID').value.trim();
        this.articleService.checkOutBook(cardID, isbn).subscribe(
            data => this.checkOutCode = data);
        console.log(this.checkOutCode);

    }

    onCheckIn() {
        this.renderSearchTable = false;
        const title = this.checkInForm.get('title').value.trim();
        this.articleService.getCheckedInBooks(title).subscribe(
            data => this.allSearchResultCheckIns = data,
            errorCode => this.statusCode = errorCode);
        this.renderSearchTable = true;
    }

    setMode1() {
        this.mode = 1;
    }
    setMode2() {
        this.mode = 2;
    }


    setMode3() {
        this.mode = 3;
    }


    setMode4() {
        this.mode = 4;
    }
    setMode5() {
        this.mode = 5;
        this.articleService.getFines()
            .subscribe(
            data => this.allFines = data,
            errorCode => this.statusCode = errorCode);
    }
    // add borrower
    addBorrowerSubmit() {

        const cardID = this.addBorrowerForm.get('cardID').value.trim();
        console.log(cardID);
        const SSN = this.addBorrowerForm.get('SSN').value.trim();
        const FirstName = this.addBorrowerForm.get('FirstName').value.trim();
        const LastName = this.addBorrowerForm.get('LastName').value.trim();
        const Email = this.addBorrowerForm.get('Email').value.trim();
        const Address = this.addBorrowerForm.get('Address').value.trim();
        const City = this.addBorrowerForm.get('City').value.trim();
        const State = this.addBorrowerForm.get('State').value.trim();
        const Phone = this.addBorrowerForm.get('Phone').value.trim();

        // handle addborrower
        const borrower = new Borrower(cardID, SSN, FirstName, LastName, Email, Address, City, State, Phone);
        this.articleService.addBorrower(borrower)
            .subscribe(
            data => this.borrowerCode = data);

    }


    // Fetch all books
    getAllSearchResults(title) {

    }







}
