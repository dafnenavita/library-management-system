package com.dafneslibrary.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.dafneslibrary.entity.Authors;
import com.dafneslibrary.entity.Book;

import com.dafneslibrary.entity.Book_Loans;
import com.dafneslibrary.entity.Borrower;
import com.dafneslibrary.entity.FineDetails;
import com.dafneslibrary.entity.Fines;
import com.dafneslibrary.entity.SearchResult;
import com.dafneslibrary.entity.SearchResultCheckIn;

@Transactional
@Repository
public class LibraryDAO implements ILibraryDAO {
	@PersistenceContext
	private EntityManager entityManager;

	
	@SuppressWarnings("unchecked")
	@Override
	public List<SearchResult> getBooksBySearchParam(String searchParam) {

		Long isbn = null;
		String hql = "";
		List<Book> bookList = null;
		List<SearchResult> resultList = new ArrayList<SearchResult>();

		if (isNumeric(searchParam)) {
			isbn = new Long(searchParam);
		}

		if (null != isbn) {
			hql = "FROM Authors a inner join a.book_Authors as ba inner join ba.book as book where " + "ba.Isbn = ?";
			bookList = entityManager.createQuery(hql).setParameter(1, isbn).getResultList();
		} else {
			hql = "FROM Authors a inner join a.book_Authors as ba inner join ba.book as book where "
					+ "a.Name like ? or " + "book.Title like ?";
			bookList = entityManager.createQuery(hql).setParameter(1, "%" + searchParam + "%")
					.setParameter(2, "%" + searchParam + "%").getResultList();
		}

		for (Object resultObj : bookList) {
			Object[] a = (Object[]) resultObj;
			SearchResult sr = new SearchResult();
			for (Object obj : a) {
				if (obj instanceof Authors) {
					sr.setAuthorName(((Authors) obj).getName());
				} else if (obj instanceof Book) {
					sr.setIsbn(((Book) obj).getIsbn());
					sr.setTitle(((Book) obj).getTitle());
				}
			}

			resultList.add(sr);
		}

		List<Book_Loans> bookLoans = entityManager.createQuery("FROM Book_Loans").getResultList();
		List<Long> checkedOutBooks = new ArrayList();
		for (Book_Loans bl : bookLoans) {
			checkedOutBooks.add(bl.getIsbn());
		}

		for (SearchResult searchResult : resultList) {
			if (checkedOutBooks.contains(searchResult.getIsbn())) {
				searchResult.setAvailability("N");
			} else {
				searchResult.setAvailability("Y");
			}
		}

		return resultList;
	}

	@Override
	public int checkOutBook(long isbn, int cardId) {

		int returnCode = 0;
		int count = entityManager.createQuery("FROM Borrower as brw where brw.card_Id = ?").setParameter(1, cardId)
				.getResultList().size();
		int count2 = entityManager.createQuery("FROM Book_Loans as bl where bl.Card_id = ?").setParameter(1, cardId)
				.getResultList().size();

		if (count > 0) {
			if (count2 < 3) {
				Book_Loans bl = new Book_Loans();
				bl.setCard_id(cardId);
				bl.setDate_out(new Date());
				bl.setDue_date(getDueDate());
				bl.setIsbn(isbn);
				entityManager.persist(bl);
				returnCode = 3;
			} else {
				returnCode = 2;
			}
		} else {
			returnCode = 1;
		}
		return returnCode;
	}

	public Date getDueDate() {
		return new Date((new Date()).getTime() + 14 * 24 * 60 * 60 * 1000);
	}

	@SuppressWarnings("unchecked")
	@Override
	public int addBorrower(Borrower borrower) {
		int returnCode = 0;
		try {
			String hql = "from Borrower br order by card_Id desc";
			List<Borrower> list = entityManager.createQuery(hql).getResultList();
			borrower.setCard_Id(list.get(0).getCard_Id() + 1);
			entityManager.persist(borrower);
		} catch (Exception e) {
			returnCode = 1;
		}
		System.out.println("Hello");
		return returnCode;

	}

	@SuppressWarnings("unchecked")
	@Override
	public List<SearchResultCheckIn> getCheckedInBooks(String searchParam) {

		String hql = "FROM Book_Loans as bl inner join bl.Borrower as br where br.bFirstname like ? "
				+ "or br.bLastname like ? " + "or bl.isbn = ? " + "or br.card_Id = ? ";
		List<SearchResultCheckIn> returnList = new ArrayList<SearchResultCheckIn>();
		List bookList = new ArrayList<>();
		Integer cardID = 0;
		Long isbn = new Long(0);

		if (isNumeric(searchParam)) {
			try {
				cardID = new Integer(searchParam);
			} catch (Exception e) {

			}
			try {
				isbn = new Long(searchParam);
			} catch (Exception e) {

			}
			bookList = entityManager.createQuery(
					"FROM Book_Loans as bl inner join bl.Borrower as br where bl.isbn = ? " + "or br.card_Id = ? ")
					.setParameter(1, isbn).setParameter(2, cardID).getResultList();
		} else {
			bookList = entityManager
					.createQuery("FROM Book_Loans as bl inner join bl.Borrower as br where br.bFirstname like ? "
							+ "or br.bLastname like ?")
					.setParameter(1, "%" + searchParam + "%").setParameter(2, "%" + searchParam + "%").getResultList();
		}

		System.out.println(bookList.size());
		for (Object resultObj : bookList) {
			Object[] a = (Object[]) resultObj;
			SearchResultCheckIn sr = new SearchResultCheckIn();
			for (Object obj : a) {
				if (obj instanceof Book_Loans) {
					Book_Loans bl = (Book_Loans) obj;
					sr.setLoan_id(bl.getLoan_id());
					sr.setDate_in(bl.getDate_in());
					sr.setDate_out(bl.getDate_out());
					sr.setDue_date(bl.getDate_out());
					sr.setCard_no(bl.getCard_id());
					sr.setIsbn(bl.getIsbn());
				} else if (obj instanceof Borrower) {
					Borrower bl = (Borrower) obj;
					sr.setbFirstname(bl.getbFirstname());
					sr.setbLastname(bl.getbLastname());
				}
			}

			returnList.add(sr);

		}

		return returnList;
	}

	public static boolean isNumeric(String str) {
		if (str == null) {
			return false;
		}
		int sz = str.length();
		for (int i = 0; i < sz; i++) {
			if (Character.isDigit(str.charAt(i)) == false) {
				return false;
			}
		}
		return true;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<FineDetails> retrieveAndUpdateFines() {
		// TODO Auto-generated method stub
		List<Book_Loans> bookLoanList = entityManager.createQuery("FROM Book_Loans").getResultList();
		List<Fines> fineList = new ArrayList<Fines>();
		try {
			fineList = entityManager.createQuery("FROM Fines").getResultList();
		} catch (Exception e) {
			System.out.println("No Fines");
		}
		
		List<Book_Loans> removeList = new ArrayList<Book_Loans>();
		List<Integer> paidFines = new ArrayList<Integer>();
		List<Fines> fineInsertList = new ArrayList<Fines>();

		for (Fines fine : fineList) {
			if (fine.getPaid() == 'Y') {
				paidFines.add(fine.getLoan_id());
			}
		}

		for (Book_Loans loan : bookLoanList) {

			if (loan.getDue_date().after(new Date())) {
				removeList.add(loan);
			} else if (null != loan.getDate_in() && loan.getDate_in().before(loan.getDue_date())) {
				removeList.add(loan);
			} else if (paidFines.contains(loan.getLoan_id())) {
				removeList.add(loan);
			}

		}

		bookLoanList.removeAll(removeList);

		for (Book_Loans bookLoanWithFine : bookLoanList) {
			Fines fine = new Fines();
			fine.setLoan_id(bookLoanWithFine.getLoan_id());
			if (null != bookLoanWithFine.getDate_in()) {
				fine.setFine_amt(getFineAmount(bookLoanWithFine.getDue_date(), bookLoanWithFine.getDate_in()));
			} else {
				fine.setFine_amt(getFineAmount(bookLoanWithFine.getDue_date(), new Date()));
			}

			fine.setPaid('N');
			entityManager.persist(fine);
		}

		List<Fines> fineListUpdated = new ArrayList<Fines>();
		try {
			fineListUpdated = entityManager.createQuery("FROM Fines").getResultList();
		} catch (Exception e) {
			System.out.println("No Fines");
		}
		
		for (Fines f : fineListUpdated) {
			
		}
		

		

		List<Fines> returnList = entityManager.createQuery("FROM Fines f").getResultList();

		return null;
	}

	public float getFineAmount(Date date1, Date date2) {

		SimpleDateFormat myFormat = new SimpleDateFormat("yyyy-mm-dd");
		Float fine = null;
		try {
			long diff = date2.getTime() - date1.getTime();
			fine = new Float(TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS) * .25);
		} catch (Exception e) {
			fine = new Float(0.0);
		}
		return fine;
	}
}
