package com.dafneslibrary.dao;

import java.util.List;


import com.dafneslibrary.entity.Borrower;
import com.dafneslibrary.entity.FineDetails;
import com.dafneslibrary.entity.SearchResult;
import com.dafneslibrary.entity.SearchResultCheckIn;

public interface ILibraryDAO {

	List<SearchResult> getBooksBySearchParam(String searchParam);

	int checkOutBook(long isbn, int cardId);

	List<SearchResultCheckIn> getCheckedInBooks(String searchParamBor);

	int addBorrower(Borrower borrower);

	List<FineDetails> retrieveAndUpdateFines();

}
