package com.dafneslibrary.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dafneslibrary.entity.Borrower;
import com.dafneslibrary.entity.FineDetails;
import com.dafneslibrary.entity.FineDisplay;
import com.dafneslibrary.entity.SearchResult;
import com.dafneslibrary.entity.SearchResultCheckIn;
import com.dafneslibrary.service.ILibraryService;

@Controller
@RequestMapping("user")
@CrossOrigin(origins = { "http://localhost:4200" })
public class LibraryController {
	@Autowired
	private ILibraryService libraryService;

	@GetMapping("book")
	public ResponseEntity<List<SearchResult>> getBooksBySearchParam(@RequestParam("searchParam") String searchParam) {
		List<SearchResult> list = libraryService.getBooksBySearchParam(searchParam);
		if(null == list || list.isEmpty()) {
			return new ResponseEntity<List<SearchResult>>(list, HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<SearchResult>>(list, HttpStatus.OK);
	}

	@PostMapping("checkOutBook")
	public ResponseEntity<Integer> checkOutBook(@RequestParam("cardId") int cardId, @RequestParam("isbn") long isbn) {
		System.out.println("CardId" + cardId);
		System.out.println("isbn" + isbn);
		Integer borrowerExists = libraryService.checkOutBook(cardId, isbn);
		return new ResponseEntity<Integer>(borrowerExists, HttpStatus.OK);
	}

	@GetMapping("checkIn")
	public ResponseEntity<List<SearchResultCheckIn>> getCheckedInBooks(
			@RequestParam("searchParam") String searchParamBor) {
		List<SearchResultCheckIn> list = libraryService.getCheckedInBooks(searchParamBor);
		return new ResponseEntity<List<SearchResultCheckIn>>(list, HttpStatus.OK);
	}

	@PostMapping("addBorrower")
	public ResponseEntity<Integer> addBorrower(@RequestBody Borrower borrower) {
		Integer returnCode = libraryService.addBorrower(borrower);

		return new ResponseEntity<Integer>(returnCode, HttpStatus.CREATED);

		
	}

	@PostMapping("retrieveAndUpdateFines")
	public ResponseEntity<List<FineDisplay>> retrieveAndUpdateFines() {

		List<FineDisplay> list = new ArrayList<FineDisplay>();
		for(int i = 0;i<5;i++) {
			FineDisplay fd = new FineDisplay();
			fd.setCardId("10");
			fd.setName("Dafe");
			fd.setFine1("10");
			fd.setFine2("10");
			fd.setFine3("10");
			fd.setPaid("Y");
			list.add(fd);
		}
		return new ResponseEntity<List<FineDisplay>>(list, HttpStatus.OK);
		
		
	}

}