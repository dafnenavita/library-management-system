package com.dafneslibrary.service;

import java.util.List;


import com.dafneslibrary.entity.Borrower;
import com.dafneslibrary.entity.FineDetails;
import com.dafneslibrary.entity.SearchResult;
import com.dafneslibrary.entity.SearchResultCheckIn;

public interface ILibraryService {

	List<SearchResult> getBooksBySearchParam(String searchParam);

	int checkOutBook(int cardId, long isbn);

	List<SearchResultCheckIn> getCheckedInBooks(String searchParamBor);

	int addBorrower(Borrower borrower);

	List<FineDetails> retrieveAndUpdateFines();

}
