package com.dafneslibrary.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dafneslibrary.dao.ILibraryDAO;
import com.dafneslibrary.entity.Borrower;
import com.dafneslibrary.entity.FineDetails;
import com.dafneslibrary.entity.SearchResult;
import com.dafneslibrary.entity.SearchResultCheckIn;
@Service
public class LibraryService implements ILibraryService {
	@Autowired
	private ILibraryDAO libraryDAO;

	@Override
    public List<SearchResult> getBooksBySearchParam(String searchParam) {
    	return libraryDAO.getBooksBySearchParam(searchParam);
    }
	@Override
	public int checkOutBook(int cardId,long isbn) {
		return libraryDAO.checkOutBook(isbn,cardId);
	}
	
	@Override
	public List<SearchResultCheckIn>getCheckedInBooks(String searchParamBor)
	{
		return libraryDAO.getCheckedInBooks(searchParamBor);
	}
	
	@Override
	public int addBorrower(Borrower borrower)
	{
		return libraryDAO.addBorrower(borrower);
	}
	@Override
	public List<FineDetails> retrieveAndUpdateFines() {
		// TODO Auto-generated method stub
		return libraryDAO.retrieveAndUpdateFines();
	}
	

}
