package com.dafneslibrary.entity;

import java.io.Serializable;
import java.util.Date;

public class SearchResultCheckIn implements Serializable {

	private static final long serialVersionUID = 1L;

	private int Loan_id;
	private int Card_no;
	private String bFirstname;
	private String bLastname;
	private long Isbn;
	private Date Date_out;
	private Date Due_date;
	private Date Date_in;

	public int getLoan_id() {
		return Loan_id;
	}

	public void setLoan_id(int loan_id) {
		Loan_id = loan_id;
	}

	public int getCard_no() {
		return Card_no;
	}

	public void setCard_no(int card_no) {
		Card_no = card_no;
	}

	public String getbFirstname() {
		return bFirstname;
	}

	public void setbFirstname(String bFirstname) {
		this.bFirstname = bFirstname;
	}

	public String getbLastname() {
		return bLastname;
	}

	public void setbLastname(String bLastname) {
		this.bLastname = bLastname;
	}

	public long getIsbn() {
		return Isbn;
	}

	public void setIsbn(long isbn) {
		Isbn = isbn;
	}

	public Date getDate_out() {
		return Date_out;
	}

	public void setDate_out(Date date_out) {
		Date_out = date_out;
	}

	public Date getDue_date() {
		return Due_date;
	}

	public void setDue_date(Date due_date) {
		Due_date = due_date;
	}

	public Date getDate_in() {
		return Date_in;
	}

	public void setDate_in(Date date_in) {
		Date_in = date_in;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
