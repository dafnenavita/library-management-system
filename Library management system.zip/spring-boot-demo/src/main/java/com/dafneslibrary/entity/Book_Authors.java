package com.dafneslibrary.entity;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Book_Authors")
public class Book_Authors implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue
	@Column(name = "Author_id")
	private int Author_id;

	@Column(name = "Isbn")
	private long Isbn;

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "Isbn", insertable = false, updatable = false)
	private Book book;

	public Book_Authors(int author_id, long isbn) {
		super();
		Author_id = author_id;
		Isbn = isbn;
	}


		  public Book_Authors() {
			  
		  }
	
	public int getAuthor_id() {
		return Author_id;
	}

	public void setAuthor_id(int author_id) {
		Author_id = author_id;
	}

	public long getIsbn() {
		return Isbn;
	}

	public void setIsbn(long isbn) {
		Isbn = isbn;
	}


}
