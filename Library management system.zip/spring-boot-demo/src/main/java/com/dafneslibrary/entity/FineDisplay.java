package com.dafneslibrary.entity;

import java.io.Serializable;

public class FineDisplay implements Serializable {

	private static final long serialVersionUID = 1L;
	private String cardId;
	private String name;
	private String fine1;
	private String fine2;
	public String getCardId() {
		return cardId;
	}

	public void setCardId(String cardId) {
		this.cardId = cardId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFine1() {
		return fine1;
	}

	public void setFine1(String fine1) {
		this.fine1 = fine1;
	}

	public String getFine2() {
		return fine2;
	}

	public void setFine2(String fine2) {
		this.fine2 = fine2;
	}

	public String getFine3() {
		return fine3;
	}

	public void setFine3(String fine3) {
		this.fine3 = fine3;
	}

	public String getPaid() {
		return paid;
	}

	public void setPaid(String paid) {
		this.paid = paid;
	}

	private String fine3;
	private String paid;

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
