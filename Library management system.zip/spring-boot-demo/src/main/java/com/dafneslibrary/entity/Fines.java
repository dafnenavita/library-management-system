package com.dafneslibrary.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "Fines")
public class Fines implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "Loan_id")
	private int loan_id;

	@Column(name = "Fine_amt")
	private float fine_amt;

	@Column(name = "Paid")
	private char paid;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "Loan_id", insertable = false, updatable = false)
	private Book_Loans bookLoan;

	public Fines(int loan_id, float fine_amt, char paid) {
		super();
		this.loan_id = loan_id;
		this.fine_amt = fine_amt;
		this.paid = paid;
	}

	public Book_Loans getBookLoan() {
		return bookLoan;
	}

	public void setBookLoan(Book_Loans bookLoan) {
		this.bookLoan = bookLoan;
	}

	public Fines() {
		// TODO Auto-generated constructor stub
	}

	public int getLoan_id() {
		return loan_id;
	}

	public void setLoan_id(int loan_id) {
		this.loan_id = loan_id;
	}

	public float getFine_amt() {
		return fine_amt;
	}

	public void setFine_amt(float fine_amt) {
		this.fine_amt = fine_amt;
	}

	public char getPaid() {
		return paid;
	}

	public void setPaid(char paid) {
		this.paid = paid;
	}

}
