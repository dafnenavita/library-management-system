package com.dafneslibrary.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;


@Entity
@Table(name = "Book_Loans")
public class Book_Loans {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name ="Loan_id")
	private int Loan_id;

	@Column(name = "Isbn")
	private long isbn;
	
	@Column(name = "Card_id")
	private int Card_id;
	
	@Column(name = "Date_out")
	private Date Date_out;
	
	@Column(name = "Date_in")
	private Date Date_in;
	
	@Column(name = "Due_date")
	private Date Due_date;
	
	public Borrower getBorrower() {
		return Borrower;
	}


	public void setBorrower(Borrower borrower) {
		Borrower = borrower;
	}

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "Card_id",insertable=false,updatable=false)
	private Borrower Borrower;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "Isbn",insertable=false,updatable=false)
	private Book book;
	
	public Book getBook() {
		return book;
	}


	public void setBook(Book book) {
		this.book = book;
	}


	public int getLoan_id() {
		return Loan_id;
	}

	public void setLoan_id(int loan_id) {
		Loan_id = loan_id;
	}

	public long getIsbn() {
		return isbn;
	}


	public void setIsbn(long isbn) {
		this.isbn = isbn;
	}


	public int getCard_id() {
		return Card_id;
	}


	public void setCard_id(int card_id) {
		Card_id = card_id;
	}


	public Date getDate_out() {
		return Date_out;
	}


	public void setDate_out(Date date_out) {
		Date_out = date_out;
	}


	public Date getDate_in() {
		return Date_in;
	}


	public void setDate_in(Date date_in) {
		Date_in = date_in;
	}


	public Date getDue_date() {
		return Due_date;
	}


	public void setDue_date(Date due_date) {
		Due_date = due_date;
	}
	


}
