package com.dafneslibrary.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Borrower")
public class Borrower implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "Card_id")
	private int card_Id;
	
	@Column(name = "Ssn")
	private int ssn;
	
	@Column(name = "BFirstname")
	private String bFirstname;
	
	@Column(name = "BLastname")
	private String bLastname;
	
	@Column(name = "BEmail")
	private String bEmail;
	
	@Column(name = "Address")
	private String address;
	
	@Column(name = "City")
	private String city;
	
	@Column(name = "State")
	private String state;
	
	@Column(name = "Phone")
	private String phone;
	
	public int getCard_Id() {
		return card_Id;
	}
	public void setCard_Id(int card_Id) {
		this.card_Id = card_Id;
	}
	public int getSsn() {
		return ssn;
	}
	public void setSsn(int ssn) {
		this.ssn = ssn;
	}
	public String getbFirstname() {
		return bFirstname;
	}
	public void setbFirstname(String bFirstname) {
		this.bFirstname = bFirstname;
	}
	public String getbLastname() {
		return bLastname;
	}
	public void setbLastname(String bLastname) {
		this.bLastname = bLastname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getbEmail() {
		return bEmail;
	}
	public void setbEmail(String bEmail) {
		this.bEmail = bEmail;
	}
}
