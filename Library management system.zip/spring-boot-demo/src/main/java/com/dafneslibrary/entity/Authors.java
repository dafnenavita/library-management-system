package com.dafneslibrary.entity;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "Authors")
public class Authors implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "Author_id")
	private long Author_id;
	
	@Column(name = "Name")
	private String Name;
	
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name = "Author_id",insertable=false,updatable=false)
	private List<Book_Authors> book_Authors;
	
	public Authors(long author_id, String name) {
		super();
		Author_id = author_id;
		Name = name;
	}

	public List<Book_Authors> getBook_Authors() {
		return book_Authors;
	}

	public void setBook_Authors(List<Book_Authors> book_Authors) {
		this.book_Authors = book_Authors;
	}

	public Authors() {
		// TODO Auto-generated constructor stub
	}

	public long getAuthor_id() {
		return Author_id;
	}

	public void setAuthor_id(long author_id) {
		Author_id = author_id;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

}
