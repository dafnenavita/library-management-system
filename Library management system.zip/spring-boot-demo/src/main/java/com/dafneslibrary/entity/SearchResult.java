package com.dafneslibrary.entity;

import java.io.Serializable;

public class SearchResult implements Serializable {

	private static final long serialVersionUID = 1L;

	private long isbn;
	private String title;
	private String authorName;
	private String availability;

	public long getIsbn() {
		return isbn;
	}

	public void setIsbn(long isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public String getAvailability() {
		return availability;
	}

	public void setAvailability(String availability) {
		this.availability = availability;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
