package com.dafneslibrary.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BOOK")
public class Book implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "Isbn")
	private long Isbn;
	
	@Column(name = "Title")
	private String Title;
	
	public Book()
	{
		
	}
	
	
	public long getIsbn() {
		return Isbn;
	}
	public void setIsbn(long isbn) {
		Isbn = isbn;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	
}
